<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your</title>
    <style>
        html,
        body {
            padding: 10px;
            background-color: #fbfbfb;
        }
        
        .container {
            border: 1px solid #ddd;
            font-family: Cambria;
            font-size: 20px;
            text-align: center;
        }
        
        .title {
            font-size: 300%;
            text-transform: uppercase;
        }
        
        .news-container {
            margin: 20px;
            padding: 20px;
            transform: scale(0.99);
            text-align: left;
            transition: all 0.4s;
        }
        
        .news-container:hover {
            box-shadow: #ccc 0px 0px 3px 5px;
            transform: scale(1.01);
        }
        
        .news-container .heading {
            font-size: 200%;
            margin-bottom: 20px;
        }
        
        .news-container .news {
            text-align: justify;
            column-gap: 50px;
            column-rule: 3px solid #ccc;
        }
        
        .news-container .news img {
            width: 100%;
        }
        
        .news.col-2 {
            column-count: 2;
        }
        
        .news.col-3 {
            column-count: 3;
        }
    </style>
</head>
<body class="container">
    <div class="title"><?php echo $contentDetails['topic_name']; ?></div>
    <div class="news-container">
        <div class="heading"><?php echo $contentDetails['sub_topic_name']; ?></div>
        <div class="news col-2">
        <img src="<?= base_url($contentDetails['img'])  ?>" />
      
  
            <p><?php echo $contentDetails['content_info']; ?></p> 
        </div>
    </div>
</body>


</html>